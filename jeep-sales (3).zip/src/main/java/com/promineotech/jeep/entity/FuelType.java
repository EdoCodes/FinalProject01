package com.promineotech.jeep.entity;

public enum FuelType {
  GASOLINE, DIESEL, HYBRID
}
