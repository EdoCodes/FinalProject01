package com.promineotech.jeep.entity;

public enum ImageMimeType {
	IMAGE_JPEG("image/jpeg");

	private String mimetype;

	private ImageMimeType(String mimeType) {
		this.mimetype = mimeType;
	}

	public String getMimetype() {
		return mimetype;
	}

	public static ImageMimeType fromString(String mimeType) {
		for (ImageMimeType imt : ImageMimeType.values()) {
			if (imt.getMimetype().equals(mimeType))
				return imt;
		}
		return null;
	}
}
