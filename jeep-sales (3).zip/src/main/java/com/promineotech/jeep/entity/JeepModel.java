package com.promineotech.jeep.entity;

public enum JeepModel {

	GRAND_CHEROKEE, CHEROKEE, COMPASS, RENEGADE, WRANGLER, GLADIATOR, WRANGLER_4XE
}
