package com.promineotech.jeep.entity;

public enum OptionType {
  DOOR, EXTERIOR, INTERIOR, STORAGE, TOP, WHEEL
}
