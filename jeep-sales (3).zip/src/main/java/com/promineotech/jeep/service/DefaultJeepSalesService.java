package com.promineotech.jeep.service;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.promineotech.jeep.dao.JeepSalesDao;
import com.promineotech.jeep.entity.Image;
import com.promineotech.jeep.entity.ImageMimeType;
import com.promineotech.jeep.entity.Jeep;
import com.promineotech.jeep.entity.JeepModel;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DefaultJeepSalesService implements JeepSalesService {

	@Autowired
	private JeepSalesDao jeepSalesDao;

	public List<Jeep> fetchJeeps(JeepModel model, String trim) {
		List<Jeep> jeeps = jeepSalesDao.fetchJeeps(model, trim);

		Collections.sort(jeeps);
		return jeeps;
	}

	@Transactional
	@Override
	public String uploadImage(MultipartFile file, Long modelPK) {
		String imageID = UUID.randomUUID().toString();
		log.debug(" Uploading image with image id = {}", imageID);
		try (InputStream inputStream = file.getInputStream()) {
			BufferedImage bufferedImage = ImageIO.read(inputStream);
			Image image = Image.builder().modelFK(modelPK).imageId(imageID).width(bufferedImage.getWidth())
					.height(bufferedImage.getHeight()).mimeType(ImageMimeType.IMAGE_JPEG)
					.name(file.getOriginalFilename()).data(toByteArray(bufferedImage, "jpeg")).build();
			jeepSalesDao.saveImage(image);
			return imageID;
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	private byte[] toByteArray(BufferedImage bufferedImage, String renderType) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			if (!ImageIO.write(bufferedImage, renderType, baos)) {
				throw new RuntimeException("Could not write to image buffer");
			}
			return baos.toByteArray();
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public Image retrieveImage(String imageId) {

		return jeepSalesDao.retrieveImage(imageId)
				.orElseThrow(() -> new NoSuchElementException("No Image with this imageId" + imageId));
	}
}
