package com.promineotech.jeep.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql(scripts = { "classpath:flyway/migrations/V1.0__Jeep_Schema.sql",
		"classpath:flyway/migrations/V1.1__Jeep_Data.sql" }, config = @SqlConfig(encoding = "utf-8"))
class ImageUploadTest {

	@Autowired
	private MockMvc mockMvc;

	private static final String JEEP_IMAGE = "jeep.jpg";

	@Test
	public void testThatTheServerCorrectlyRecievesAnImageAndReturnsAnOKResponse() throws Exception {

		String json = assertImageUpload();
		String imageId = extractImageId(json);

		assertImageRetrievel(imageId);
	}

	private void assertImageRetrievel(String imageId) throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/jeeps/image/" + imageId))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	private String extractImageId(String json) {
		String[] parts = json.substring(1, json.length() - 1).split(":");
		return parts[1].substring(1, parts[1].length() - 1);
	}

	private String assertImageUpload() throws IOException, Exception, UnsupportedEncodingException {
		Resource image = new ClassPathResource(JEEP_IMAGE);
		if (!image.exists()) {
			fail("Image Error", JEEP_IMAGE);
		}
		try (InputStream inputStream = image.getInputStream()) {
			MockMultipartFile file = new MockMultipartFile("image", JEEP_IMAGE, MediaType.TEXT_PLAIN_VALUE,
					inputStream);
			MvcResult result = this.mockMvc.perform(MockMvcRequestBuilders.multipart("/jeeps/1/image").file(file))
					.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().is(201)).andReturn();
			String content = result.getResponse().getContentAsString();
			assertThat(content).isNotEmpty();
			return content;
		}
	}

}
